a = 10
b = 12
c = a+b
print(c)